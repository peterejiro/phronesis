<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<footer class="main-footer">
  <div class="footer-left">
    Copyright © 2020 <div class="bullet"></div> Design by <a href="https://connexxiontelecom.com" target="_blank">Connexxion Telecom</a>
  </div>
</footer>
